
/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file 
  * @author David Damian alu0101674179@ull.edu.es 
  * @date Oct 30 2023
  * @brief The program  
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P48107
  */

#include <iostream>

int main() {

	int x, y;
	std::cin >> x >> y;
	

	if (x>y) {	

	for (int i=x; i>= y; i--) {
	std::cout << i << std::endl;
}}	
	else if (x<y) {
	for (int i=y; i>= x; i--) {
	std::cout << i << std::endl;
}}
	else {
	std::cout << x << std::endl;
}} 
