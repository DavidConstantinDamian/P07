
/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file 
  * @author David Damian alu0101674179@ull.edu.es 
  * @date Oct 24 2023
  * @brief The program  
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P48107
  */

#include <iostream>

bool isBinary(const char* input) {
    while (*input) {
        if (*input != '0' && *input != '1') {
            return false;
        }
        input++;
    }
    return true;
}

int binaryToDecimal(const char* binary) {
    int result = 0;
    while (*binary) {
        result = (result << 1) + (*binary - '0');
        binary++;
    }
    return result;
}

int main() {
    char binary[32]; 
    std::cin >> binary;

    if (isBinary(binary)) {
        int decimal = binaryToDecimal(binary);
        std::cout << decimal << std::endl;
    } else {
        std::cout << "Wrong Input" << std::endl;
    }

    return 0;
}

