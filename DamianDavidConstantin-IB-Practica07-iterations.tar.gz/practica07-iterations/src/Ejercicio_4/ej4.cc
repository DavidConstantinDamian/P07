/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file 
  * @author David Damian alu0101674179@ull.edu.es 
  * @date Oct 24 2023
  * @brief The program  
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P48107
  */

#include <iostream>

int decimalToBinary(int decimal) {
    int binary = 0;
    int base = 1;

    while (decimal > 0) {
        binary += (decimal % 2) * base;
        decimal /= 2;
        base *= 10;
    }

    return binary;
}

int main() {
    int decimal;
    std::cin >> decimal;

    int binary = decimalToBinary(decimal);
    std::cout << binary << std::endl;

    return 0;
}

