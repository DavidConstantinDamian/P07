/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file 
  * @author David Damian alu0101674179@ull.edu.es 
  * @date Oct 24 2023
  * @brief The program  
  * @bug There are no known bugs
  * @see https://jutge.org/problems/
  */

#include <iostream>

bool isLeapYear(int years) {
    if (years % 100 == 0) {
        return (years % 400 == 0);
    } else {
        return (years % 4 == 0);
    }
}

void printLeapYearStatus(bool isLeap) {
    if (isLeap) {
        std::cout << "YES";
    } else {
        std::cout << "NO";
    }
}

int main() {
    int years;
    std::cin >> years;

    bool leap = isLeapYear(years);

    printLeapYearStatus(leap);

    return 0;
}

