/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file 
  * @author David Damian alu0101674179@ull.edu.es 
  * @date Oct 24 2023
  * @brief The program  
  * @bug There are no known bugs
  */
  
#include <iostream>

int getInput() {
    int num;
    std::cin >> num;
    return num;
}

int fibonacci(int num) {
    int primero = 0, segundo = 1, siguiente;

    for (int i = 0; i <= num; i++) {
        if (i <= 1) {
            siguiente = i;
        } else {
            siguiente = primero + segundo;
            primero = segundo;
            segundo = siguiente;
        }

        std::cout << siguiente << " ";
    }
    return 0;
}

int main() {
    int num = getInput();
    int result = fibonacci(num);
    return result;
}
 
