/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2023-2024
 *
 * @file
 * @author David Damian alu0101674179@ull.edu.es
 * @date Oct 30, 2023
 * @brief The program reads pairs of numbers n and m with n ≥ m, and for each pair prints Hn − Hm
 * @bug There are no known bugs
 * @see https://jutge.org/problems/P58153
 */

#include <iostream>

  int main() {
  int first_number, second_number;
  std::cin >> first_number >> second_number;
  double harm_1 = 0.0;
  double harm_2 = 0.0;
 
 for (int i=1; i <= first_number; i++) { 
  harm_1 += 1.0/i;
}
 
 for (int i=1; i <= second_number; i++) {
  harm_2 += 1.0/i;
}
  std::cout << harm_1 - harm_2;
}
