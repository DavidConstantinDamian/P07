
/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file 
  * @author David Damian alu0101674179@ull.edu.es 
  * @date Oct 24 2023
  * @brief The program  
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P48107
  */

#include <iostream>

using namespace std;

// Function to input a number from the user
int getInput() {
    int num;
    cin >> num;
    return num;
}

int computeSumOfDigits(int num) {
    int suma = 0;
    while (num > 0) {
        int elduro = num % 10;
        suma += elduro;
        num /= 10;
    }
    return suma;
}

void displayResult(int result) {
    cout << result << endl;
}

int main() {
    int num = getInput();
    int suma = computeSumOfDigits(num);
    displayResult(suma);
    return 0;
}

